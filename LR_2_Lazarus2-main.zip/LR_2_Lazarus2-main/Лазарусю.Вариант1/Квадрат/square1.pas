unit Square1;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, Buttons, StdCtrls,Math;

type

  { TForm1 }

  TForm1 = class(TForm)
    BitBtn1: TBitBtn;
    Button1: TButton;
    Button2: TButton;
    Edit1: TEdit;
    Edit2: TEdit;
    Edit3: TEdit;
    Edit4: TEdit;
    Label1: TLabel;
    Label2: TLabel;
    Label3: TLabel;
    Label4: TLabel;
    Memo1: TMemo;
    procedure BitBtn1Click(Sender: TObject);
    procedure Button1Click(Sender: TObject);
    procedure Button2Click(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure Label1Click(Sender: TObject);
  private

  public

  end;

var
  Form1: TForm1;

implementation

{$R *.lfm}

{ TForm1 }

procedure TForm1.FormCreate(Sender: TObject);
begin

end;

procedure TForm1.Button1Click(Sender: TObject);
var x1,x2,y1,y2:integer;
  a, P,S:real;
begin
  x1:=strtoint(edit1.text);
  y1:=strtoint(edit2.text);
  x2:=strtoint(edit3.text);
  y2:=strtoint(edit4.text);
  a:=roundto(sqrt(power((x2-x1),2)+power((y2-y1),2)),-2);
  P:=roundto(a*4,-2);
  S:=roundto(a*a,-2);
  memo1.lines.add('При стороне a,которая равна '+ floattostr(a)+' площадь равна '+floattostr(S)+' ,a периметр равен '+ floattostr(P));
end;

procedure TForm1.Button2Click(Sender: TObject);
begin
  edit1.clear;
  edit2.clear;
  edit3.clear;
  edit4.clear;
  edit1.setfocus;
  memo1.clear;
end;

procedure TForm1.BitBtn1Click(Sender: TObject);
begin
  close;
end;

procedure TForm1.Label1Click(Sender: TObject);
begin

end;

end.

