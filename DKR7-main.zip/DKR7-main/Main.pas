﻿uses GraphABC, LevyFractal;

var
  startX, startY: Real;
  p: Integer = 0;  
  scale: Real = 3.0;
  baseLen: Real = 50;    
  moveStep: Real = 20;

procedure Draw;
begin
  ClearWindow;

  LockDrawing;

  DrawLevyFractal(startX, startY, 0, baseLen * scale, p);

  Font.Name := 'Arial';
  Font.Size := 12;
  Font.Color := clBlack;

  TextOut(10, 10, '+ / - : глубина  (текущая: ' + p.ToString + ')');
  TextOut(10, 30, 'M / N : масштаб  (текущий: ' + (Round(scale * 10)/10).ToString + ')');
  TextOut(10, 50, 'Стрелки : перемещение');

  Redraw;
end;

procedure KeyPress(ch: char);
begin
  case UpCase(ch) of
    '+': begin p := p + 1; Draw; end;
    '-': if p > 0 then begin p := p - 1; Draw; end;
    'M': begin scale := scale * 1.1; Draw; end;
    'N': begin scale := scale / 1.1; Draw; end;
  end;
end;

procedure KeyDown(key: integer);
begin
  case key of
    VK_Up: startY := startY - moveStep;
    VK_Down: startY := startY + moveStep;
    VK_Left: startX := startX - moveStep;
    VK_Right: startX := startX + moveStep;
  end;
  Draw;
end;

begin
  SetWindowSize(800, 600);

  startX := WindowWidth div 2;
  startY := WindowHeight div 2;

  OnKeyPress := KeyPress;
  OnKeyDown := KeyDown;

  Draw;
end.
