﻿uses GraphABC;

var
  p: Integer = 0;        // начальная глубина = 0 (просто палочка)
  scale: Real = 3.0;     // масштаб
  startX, startY: Real;  // позиция кривой
  baseLen: Real = 50;    // длина базового отрезка
  moveStep: Real = 20;   // шаг перемещения стрелками

// рекурсивная кривая Леви
procedure levy(x, y, a, r: real; k: integer);//параметризация
begin
  if k > 0 then
  begin
    r := r * sin(pi/4);
    levy(x, y, a + pi/4, r, k - 1);//декомпозиция
    levy(x + r*cos(a + pi/4), y - r*sin(a + pi/4), a - pi/4, r, k - 1);//декомпозиция
  end
  else
    Line(Round(x), Round(y), Round(x + r*cos(a)), Round(y - r*sin(a)));//база рекурсии
end;

// отрисовка кривой
procedure DrawLevy;
begin
  ClearWindow;
  levy(startX, startY, 0, baseLen * scale, p);
end;

// обработка клавиш
procedure KeyPress(ch: char);
begin
  case ch of
    '+': begin
           p := p + 1;   // увеличиваем глубину
           DrawLevy;
         end;
    '-': begin
           if p > 0 then  // уменьшаем глубину, не меньше 0
             p := p - 1;
           DrawLevy;
         end;
  end;
end;

// перемещение стрелками
procedure KeyDown(key: integer);
begin
  case key of
    VK_Up: startY := startY - moveStep;
    VK_Down: startY := startY + moveStep;
    VK_Left: startX := startX - moveStep;
    VK_Right: startX := startX + moveStep;
  end;
  DrawLevy;
end;

begin
  SetWindowSize(800, 600);

  // стартовая позиция — центр окна
  startX := WindowWidth div 2;
  startY := WindowHeight div 2;

  OnKeyPress := KeyPress;
  OnKeyDown := KeyDown;

  DrawLevy;
end.
