﻿unit LevyFractal;

interface
uses GraphABC;

procedure DrawLevyFractal(x, y: Real; angle, r: Real; depth: Integer);

implementation

procedure DrawLevyFractal(x, y: Real; angle, r: Real; depth: Integer);//параметризация
begin
  if depth > 0 then
  begin
    r := r * sin(pi/4);
    DrawLevyFractal(x, y, angle + pi/4, r, depth - 1);//декомпозиция
    DrawLevyFractal(x + r*cos(angle + pi/4), y - r*sin(angle + pi/4), angle - pi/4, r, depth - 1);//декомпозиция
  end
  else
    Line(Round(x), Round(y), Round(x + r*cos(angle)), Round(y - r*sin(angle)));//база рекурсии
end;

end.
