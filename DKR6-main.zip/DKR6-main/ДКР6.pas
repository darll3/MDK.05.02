﻿uses CRT;

const
  MAX = 5;

type
  Node = record
    data: integer;
    next: integer;
  end;

var
  list: array[1..MAX] of Node;
  head: integer;
  freeHead: integer;
  choice, value: integer;
  i: integer;
  newIndex: integer;

procedure AddFirst(val: integer);
begin
  if freeHead = 0 then
  begin
    writeln('Список переполнен!');
    exit;
  end;

  newIndex := freeHead;
  freeHead := list[freeHead].next;

  list[newIndex].data := val;
  list[newIndex].next := head;
  head := newIndex;
end;

procedure AddLast(val: integer);
begin
  if freeHead = 0 then
  begin
    writeln('Список переполнен!');
    exit;
  end;

  newIndex := freeHead;
  freeHead := list[freeHead].next;

  list[newIndex].data := val;
  list[newIndex].next := 0;

  if head = 0 then
    head := newIndex
  else
  begin
    i := head;
    while list[i].next <> 0 do
      i := list[i].next;
    list[i].next := newIndex;
  end;
end;

procedure DeleteFirst;
var
  temp: integer;//указатель, который держит указатель ячейки
 begin
  if head = 0 then
    writeln('Список пуст')
  else
  begin
    temp := head;
    head := list[head].next;

    list[temp].next := freeHead;
    freeHead := temp;
    
    writeln('Элемент удалён.');
  end;
end;

procedure PrintList;
var
  i: integer;
begin
  if head = 0 then
    writeln('Список пуст')
  else
  begin
    i := head;
    while i <> 0 do
    begin
      write('[', list[i].data, ']->');
      i := list[i].next;
    end;
    writeln('nil');
  end;
end;

begin
  head := 0;
  freeHead := 1;
  
  for i := 1 to MAX - 1 do
    list[i].next := i + 1;
  list[MAX].next := 0; 

  repeat
    writeln('1. Добавить элемент в начало');
    writeln('2. Добавить элемент в конец');
    writeln('3. Удалить первый элемент');
    writeln('4. Показать список');
    writeln('5. Выход');
    write('Выберите действие: ');
    readln(choice);

    case choice of
      1:
        begin
          write('Введите значение: ');
          readln(value);
          AddFirst(value);
        end;
      2:
        begin
          write('Введите значение: ');
          readln(value);
          AddLast(value);
        end;
      3: DeleteFirst;
      4: PrintList;
    end;

  until choice = 5;
end.