unit unit4;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, StdCtrls, Buttons;

type

  { TForm1 }

  TForm1 = class(TForm)
    BitBtn1: TBitBtn;
    BitBtn2: TBitBtn;
    Edit1: TEdit;
    Edit2: TEdit;
    Edit3: TEdit;
    Label1: TLabel;
    Label2: TLabel;
    Label3: TLabel;
    Memo1: TMemo;
    procedure BitBtn1Click(Sender: TObject);
    procedure BitBtn2Click(Sender: TObject);
  private

  public

  end;

var
  Form1: TForm1;

implementation

{$R *.lfm}

{ TForm1 }

procedure TForm1.BitBtn1Click(Sender: TObject);
var a,b,h,y,x: integer;
begin
     a := strtoint(Edit1.Text);
     b := strtoint(Edit2.Text);
     h := strtoint(Edit3.Text);

     x := a;

     while x <= b do
     begin
     y := Sqr(x);

     Memo1.Lines.Add('При x = ' + FloatToStr(x) + ' значение y = ' + FloatToStr(y));
     x := x + h;
     end;
     //Memo1.Lines.Add('x = ' + FloatToStr(x) + '; y = ' + FloatToStr(y));
end;

procedure TForm1.BitBtn2Click(Sender: TObject);
begin
  close;
end;

end.

