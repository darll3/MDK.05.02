unit unit3;

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, StdCtrls, Buttons;

type

  { TForm2 }

  TForm2 = class(TForm)
    BitBtn1: TBitBtn;
    Edit1: TEdit;
    Edit2: TEdit;
    Label1: TLabel;
    Label2: TLabel;
    Memo1: TMemo;
    procedure Label1Click(Sender: TObject);
    procedure Label2Click(Sender: TObject);
    procedure Memo1Change(Sender: TObject);
  private

  public

  end;

var
  Form2: TForm2;

implementation
uses Math;

{$R *.lfm}

{ TForm2 }

procedure TForm2.Label2Click(Sender: TObject);
begin

end;

procedure TForm2.Memo1Change(Sender: TObject);
var k1, k2, t:integer;
    //t: Double;
begin
  k1:=StrToInt(Edit1.text);
  k2:=StrToInt(Edit2.text);
  t:= Round(Intpower(k1,k2));
  memo1.Lines.add('число '+Edit1.Text+' в степени '+Edit2.Text+' равно: '+IntToStr(t));
end;

procedure TForm2.Label1Click(Sender: TObject);
begin

end;

end.

