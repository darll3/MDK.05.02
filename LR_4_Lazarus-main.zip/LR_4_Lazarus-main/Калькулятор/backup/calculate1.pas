unit calculate1;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, StdCtrls, ExtCtrls;

type
  { TForm1 }
  TForm1 = class(TForm)
    butBack, but9, butSqr, but4, but5, but6, butStep, butYmn, butDropx: TButton;
    but1, but0, but2, but3, butMin, butZapat, butPlus, butRes, but7, but8: TButton;
    butZap, butAll: TButton;
    Polevivoda: TMemo;
    procedure butBackClick(Sender: TObject);
    procedure butDropxClick(Sender: TObject);
    procedure butSqrClick(Sender: TObject);
    procedure butStepClick(Sender: TObject);
    procedure butZapClick(Sender: TObject);
    procedure DigitClick(Sender: TObject);
    procedure OpClick(Sender: TObject);
    procedure butResClick(Sender: TObject);
    procedure butAllClick(Sender: TObject);
    procedure butZapatClick(Sender: TObject);
    procedure FormCreate(Sender: TObject);
  private
  public
  end;

var
  Form1: TForm1;
  FirstNum, SecondNum: Double;
  Op: string;
  IsNewInput: Boolean;

implementation

{$R *.lfm}

// Начальные настройки при запуске
procedure TForm1.FormCreate(Sender: TObject);
begin
  DefaultFormatSettings.DecimalSeparator := ','; // запятая разделитель
  IsNewInput := False;
end;

// Кнопка С — это полный сброс всего
procedure TForm1.butAllClick(Sender: TObject);
begin
  Polevivoda.Text := '0';
  FirstNum := 0;
  SecondNum := 0;
  Op := ''; // убираем операцию
end;

// Проверка на запятую
procedure TForm1.butZapatClick(Sender: TObject);
begin
  if Pos(DefaultFormatSettings.DecimalSeparator, Polevivoda.Text) = 0 then
    Polevivoda.Text := Polevivoda.Text + DefaultFormatSettings.DecimalSeparator;
end;

// Для всех кнопок от 0 до 9
procedure TForm1.DigitClick(Sender: TObject);
begin
     // Ограничение длины
  if Length(Polevivoda.Text) >= 15 then Exit;
  // Если нажали на операцию, очищаем экран для нового числа
  if IsNewInput then
  begin
    Polevivoda.Text := '';
    IsNewInput := False;
  end;
  // Если на экране 0, то убираем его, чтоб не было 06
  if Polevivoda.Text = '0' then Polevivoda.Text := '';
  // Добавляем к тексту на экране цифру, которая на кнопке
  Polevivoda.Text := Polevivoda.Text + (Sender as TButton).Caption;
end;

// СЕ — очистить только текущий ввод
procedure TForm1.butZapClick(Sender: TObject);
begin
  Polevivoda.Text := '0';
end;

// BackSpace — удаление последнего символа
procedure TForm1.butBackClick(Sender: TObject);
var s: string;
begin
  s := Polevivoda.Text;
  if s <> '' then Delete(s, Length(s), 1); // удаляем последний символ
  if (s = '') or (s = '-') then s := '0';  // если строка осталась пустой или остался только минус, заменяем на ноль
  Polevivoda.Text := s;
end;

// Дробь (1/x) с защитой от переполнения
procedure TForm1.butDropxClick(Sender: TObject);
var temp: Double;
begin
  if TryStrToFloat(Polevivoda.Text, temp) then
  begin
    if temp <> 0 then
    begin
      try
        Polevivoda.Text := FloatToStr(1 / temp);
      except
        on EMathError do ShowMessage('Ошибка: Переполнение при вычислении дроби!');
      end;
    end
    else
      ShowMessage('Ошибка: деление на ноль!');
  end;
end;

// Квадратный корень
procedure TForm1.butSqrClick(Sender: TObject);
var temp: Double;
begin
  if TryStrToFloat(Polevivoda.Text, temp) then
  begin
    if temp < 0 then
      ShowMessage('Ошибка: корень из отрицательного числа!')
    else
      Polevivoda.Text := FloatToStr(sqrt(temp));
  end;
end;

procedure TForm1.butStepClick(Sender: TObject);
var
  temp: Double;
begin
  if TryStrToFloat(Polevivoda.Text, temp) then
  begin
    // Проверка на переполнение
    if Abs(temp) > 1E154 then
    begin
      ShowMessage('Ошибка: слишком большое число!');
      Polevivoda.Text := '0';
      Exit;
    end;

    Polevivoda.Text := FloatToStr(Sqr(temp));
  end;
end;

// Выбор операции
procedure TForm1.OpClick(Sender: TObject);
begin
  if TryStrToFloat(Polevivoda.Text, FirstNum) then // сохраняем число с экрана в переменную FirstNum
  begin
    Op := (Sender as TButton).Caption; // запоминаем какой знак был на кнопке
    IsNewInput := True; // след нажатие на цифру должно очистить экран
  end;
end;

// Кнопка "=" с полной защитой от переполнения и деления на 0
procedure TForm1.butResClick(Sender: TObject);
var
  ResultValue: Double;
begin
  if (Op = '') or IsNewInput then Exit; // Если операция не выбрана, ничего не делать

  if TryStrToFloat(Polevivoda.Text, SecondNum) then  // сохраняем то что на экране во второе число
  begin
    try
      case Op of  // смотрим что за операция
        '+': ResultValue := FirstNum + SecondNum;
        '-': ResultValue := FirstNum - SecondNum;
        '*': ResultValue := FirstNum * SecondNum;
        '/':
        begin
          if SecondNum <> 0 then
            ResultValue := FirstNum / SecondNum
          else
          begin
            ShowMessage('Деление на 0 невозможно!');
            Exit;
          end;
        end;
      else
        Exit;
      end;

      // Если вычисление прошло успешно, выводим результат
      Polevivoda.Text := FloatToStr(ResultValue);
      IsNewInput := True;

    except
      on EOverflow: EMathError do
      begin
        ShowMessage('Ошибка: Число слишком великое (Переполнение)!');
        butAllClick(Sender); // Сбрасываем калькулятор в 0
      end;
      on E: Exception do
        ShowMessage('Ошибка: ' + E.Message);
    end;
  end;
end;

end.
