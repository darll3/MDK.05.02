﻿begin
  var L := Lst(ArrRandomInteger(10, 0, 100));
  
  write('список: ');
  L.Println;

  var maxIndex := L.IndexMax;

  L.RemoveAt(maxIndex);

  write('результат: ');
  L.Print;
end.