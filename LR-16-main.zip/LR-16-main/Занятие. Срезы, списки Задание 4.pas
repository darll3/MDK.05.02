﻿begin
  var a := ArrRandomInteger(10);
  writeln('массив: ', a);
  
  var maxIndex := a.IndexMax;
 
  a := a[:maxIndex] + a[maxIndex+1:];
  
  writeln('результат: ', a);
end.