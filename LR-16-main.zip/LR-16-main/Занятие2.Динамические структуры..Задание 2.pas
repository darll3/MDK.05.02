﻿type
  PNode = ^Node;
  Node = record
    data: integer;
    next: PNode;
  end;

function CreateNode(x: integer): PNode;
var n: PNode;
begin
  New(n);
  n^.data := x;
  n^.next := nil;
  CreateNode := n;
end;

procedure AddLast(var h: PNode; x: integer);
var n, p: PNode;
begin
  n := CreateNode(x);
  if h = nil then
    h := n
  else
  begin
    p := h;
    while p^.next <> nil do
      p := p^.next;
    p^.next := n;
  end;
end;

var
  head: PNode;
  p: PNode;
  i: integer;

begin
  head := nil;
  
  for i := 1 to 10 do
    AddLast(head, i);
  
  writeln('Весь список:');
  p := head;
  while p <> nil do
  begin
    write(p^.data, ' ');
    p := p^.next;
  end;
  writeln;
  
  writeln('Четные элементы:');
  p := head;
  while p <> nil do
  begin
    if p^.data mod 2 = 0 then
      write(p^.data, ' ');
    p := p^.next;
  end;
  writeln;
end.