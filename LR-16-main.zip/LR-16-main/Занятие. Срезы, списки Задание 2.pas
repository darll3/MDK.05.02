﻿begin
  var n := ReadInteger('N =');
  var a := ReadArrInteger(n);
 
  a[1::2].Print;
end.