﻿begin
  var a := ArrRandomInteger(10, 1, 100);
  writeln('массив: ', a);
  
  var n := ReadInteger('введите n:');
  
  var minIndex := a.IndexMin;
  
  a := a[:minIndex] + Arr(n) + a[minIndex:];
  
  writeln('результат: ', a);
end.