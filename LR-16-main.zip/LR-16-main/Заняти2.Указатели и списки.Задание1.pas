﻿type
  PNode = ^Node;
  Node = record
    word: string;
    count: integer;
    next: PNode;
  end;

function CreateNode(w: string): PNode;
var n: PNode;
begin
  New(n);
  n^.word := w;
  n^.count := 1;
  n^.next := nil;
  CreateNode := n;
end;

procedure AddWord(var h: PNode; w: string);
var p: PNode;
begin
  p := h;

  while p <> nil do
  begin
    if p^.word = w then
    begin
      p^.count := p^.count + 1;
      exit;
    end;
    p := p^.next;
  end;

  p := CreateNode(w);
  p^.next := h;
  h := p;
end;

var
  head, p: PNode;
  w: string;
  n, i, countWords: integer;

begin
  head := nil;

  writeln('Сколько слов ввести?');
  readln(n);

  for i := 1 to n do
  begin
    readln(w);
    AddWord(head, w);
  end;

  countWords := 0;
  p := head;
  while p <> nil do
  begin
    countWords := countWords + 1;
    p := p^.next;
  end;

  writeln('Количество различных слов: ', countWords);
end.