﻿begin
  var a := ArrRandomInteger(10, -5, 20);
  println('массив: ', a); 
  var L1 := new List<integer>;
  var L2 := new List<integer>;
 
  foreach var x in a do
    if x > 0 then
      L1 += x
    else if x < 0 then
      L2 += x;
      
  print('L1: ');
  L1.Println;
  print('L2: ');
  L2.Println;
end.