﻿begin
  var n := ReadInteger('N = ');
  var a := ArrRandomInteger(n);
  a.Println;
  96 79 71 87 61 21 51 74 67 89
  var slice := a[1::2];
  
  writeln('срез: ', slice);
  var minValue := slice.Min;
  writeln('мин: ', minValue);
end.