﻿type
  PNode = ^Node;
  Node = record
    data: integer;
    next: PNode;
  end;

function CreateNode(x: integer): PNode;
var n: PNode;
begin
  New(n);
  n^.data := x;
  n^.next := nil;
  CreateNode := n;
end;

procedure AddLast(var h: PNode; x: integer);
var n, p: PNode;
begin
  n := CreateNode(x);
  if h = nil then
    h := n
  else
  begin
    p := h;
    while p^.next <> nil do
      p := p^.next;
    p^.next := n;
  end;
end;

var
  head: PNode;
  p: PNode;
  i, x: integer;
  max, min: integer;

begin
  head := nil;
  
  writeln('Введите 10 элементов списка:');
  for i := 1 to 10 do
  begin
    read(x);
    AddLast(head, x);
  end;
  
  writeln('Список:');
  p := head;
  while p <> nil do
  begin
    write(p^.data, ' ');
    p := p^.next;
  end;
  writeln;
  
  if head <> nil then
  begin
    max := head^.data;
    min := head^.data;
    
    p := head^.next;
    while p <> nil do
    begin
      if p^.data > max then max := p^.data;
      if p^.data < min then min := p^.data;
      p := p^.next;
    end;
    
    writeln('Максимальный элемент: ', max);
    writeln('Минимальный элемент: ', min);
  end
  else
    writeln('Список пуст');
end.