﻿type
  toy = record
    name: string;
    price: real;
    age: string;
  end;

var
  toys: array[1..3] of toy;
  i: integer;

begin
  with toys[1] do
  begin
    name := 'Машинка';
    price := 1500;
    age := '3-6 лет';
  end;

  with toys[2] do
  begin
    name := 'Конструктор';
    price := 1000;
    age := '6-12 лет';
  end;

  with toys[3] do
  begin
    name := 'Кукла';
    price := 500;
    age := '4-8 лет';
  end;

  writeln('Название        Цена        Возраст');
  writeln('---------------------------------------------');

  for i := 1 to 3 do
    writeln(toys[i].name:15, toys[i].price:10:2, toys[i].age:15);
end.