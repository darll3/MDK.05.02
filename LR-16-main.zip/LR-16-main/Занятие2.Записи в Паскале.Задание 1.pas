﻿type
  anketa = record
    fio: string;
    birth: string;
    kurs: 1..5;
  end;
var
  student: anketa;
begin
  student.fio := 'Иванов И.И.';
  student.birth := '12.05.2004';
  student.kurs := 3;

  writeln(student.fio);
  writeln(student.birth);
  writeln(student.kurs);
end.