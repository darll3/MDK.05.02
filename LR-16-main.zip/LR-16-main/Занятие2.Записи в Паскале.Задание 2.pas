﻿program StudentsTable;

type
  anketa = record
    fio: string;
    birth: string;
    kurs: 1..5;
  end;

var
  students: array[1..3] of anketa;
  i: integer;

begin
  students[1].fio := 'Иванов И.И.';
  students[1].birth := '12.05.2004';
  students[1].kurs := 2;

  students[2].fio := 'Петров П.П.';
  students[2].birth := '03.11.2003';
  students[2].kurs := 3;

  students[3].fio := 'Сидорова А.А.';
  students[3].birth := '21.07.2005';
  students[3].kurs := 1;

  writeln('Ф.И.О.              Дата рожд.     Курс');
  writeln('---------------------------------------------');

  for i := 1 to 3 do
    writeln(students[i].fio:13, students[i].birth:15, students[i].kurs:8);

end.