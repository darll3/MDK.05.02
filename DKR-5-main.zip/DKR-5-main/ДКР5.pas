﻿uses CRT;

// Компараторы
function ПоВозрастанию(a, b: integer): boolean; 
begin
  result := a < b;
end;

function ПоУбыванию(a, b: integer): boolean; 
begin
  result := a > b;
end;

// Сортировка выбором
procedure СортировкаВыбором(var arr: array of integer; cm: function(x, y: integer): boolean);
var
  i, j, minIdx, temp: integer;
begin
  for i := 0 to High(arr) - 1 do
  begin
    minIdx := i;
    for j := i + 1 to High(arr) do
    begin
      if cm(arr[j], arr[minIdx]) then
        minIdx := j;
    end;
    // Меняем местами минимальный элемент с текущим
    temp := arr[i];
    arr[i] := arr[minIdx];
    arr[minIdx] := temp;
  end;
end;

// Подсчёт разряда
procedure ПодсчитатьРазряд(var arr: array of integer; exp: integer);
var
  arr2: array of integer; 
  c: array[0..9] of integer; 
  i, d: integer; 
begin
  SetLength(arr2, Length(arr));

  for i := 0 to 9 do c[i] := 0;

  for i := 0 to High(arr) do
  begin
    d := (arr[i] div exp) mod 10;
    c[d] += 1;
  end;

  for i := 1 to 9 do
    c[i] += c[i-1];

  for i := High(arr) downto 0 do
  begin
    d := (arr[i] div exp) mod 10;
    arr2[c[d]-1] := arr[i];
    c[d] -= 1;
  end;

  arr := arr2;
end;

// Поразрядная сортировка
procedure ПоразряднаяСорт(var arr: array of integer);
var
  i, m, e: integer; 
begin
  if Length(arr) = 0 then 
    exit;

  m := arr[0];  // находим максимальное число
  for i := 1 to High(arr) do
    if arr[i] > m then m := arr[i];

  e := 1;  // сортируем по разрядам начиная с 1
  while m div e > 0 do
  begin
    ПодсчитатьРазряд(arr, e);
    e *= 10;
  end;
end;

var
  arr: array of integer; 
  cmp: function(x, y: integer): boolean; 
  s, c, t, i, j: integer; 
  inf, outf: string; 
  f: text;
  v: integer;
  n: integer;
begin
  inf := 'C:\Users\dlebe\Колледж\Оаип\ДКР\DCR5\input.txt';
  outf := 'C:\Users\dlebe\Колледж\Оаип\ДКР\DCR5\output.txt';

  ClrScr;
  writeln('Исследование алгоритмов сортировки');
  writeln;

  writeln('Выберите тип сортировки:');
  writeln('1.Cортировка выбором');
  writeln('2.Поразрядная сортировка');
  write('Выбор: ');
  readln(s);

  writeln;
  writeln('Выберите компаратор:');
  writeln('1.По возрастанию');
  writeln('2.По убыванию');
  write('Выбор: ');
  readln(c);

  if c = 1 then cmp := ПоВозрастанию
  else cmp := ПоУбыванию;

  // Чтение массива
  assign(f, inf);
  reset(f);

  n := 0;  // счетчик элементов
  while not eof(f) do
  begin
    if not eoln(f) then
    begin
      read(f, v);  // читаем число
      SetLength(arr, n + 1);
      arr[n] := v;
      n += 1;
    end
    else readln(f);  // следующая строка
  end;

  close(f);

  case s of
    1: СортировкаВыбором(arr, cmp);

    2: begin
         ПоразряднаяСорт(arr);
         if c = 2 then
         begin
           i := 0; j := High(arr);
           while i < j do
           begin
             t := arr[i];
             arr[i] := arr[j];
             arr[j] := t;
             i += 1;
             j -= 1;
           end;
         end;
       end;
  end;

  // Сохранение массива
  assign(f, outf);
  rewrite(f);

  for i := 0 to High(arr) do
    writeln(f, arr[i]);

  close(f);

  writeln;
  writeln('Результат записан в файл: ', outf);
  ReadKey;
end.
