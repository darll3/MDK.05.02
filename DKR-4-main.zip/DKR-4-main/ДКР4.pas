﻿
uses GraphABC;

function f(x: real): real;
begin
  f := 2 * x * x * x + 2 * x * x + 5 * x + 19;
end;

// Метод левых прямоугольников для вычисления площади
procedure LeftRectangles(a, b: real; n: integer; var S: real);
var
  h, x: real;
begin
  h := (b - a) / n;  // Ширина прямоугольников
  S := 0;
  x := a;  // Начальная точка
  
  // Используем значения функции в левых точках для вычисления площади
  while x < b do
  begin
    S := S + f(x);   // Площадь каждого прямоугольника
    x := x + h;      // Переходим к следующему прямоугольнику
  end;
  
  S := S * h;  // Умножаем на ширину, чтобы получить итоговую площадь
end;

// Процедура для отрисовки графика функции
procedure drawGraph(a, b: real; n: integer);
var
  x, y: real;
  i, x0, y0, width, height: integer;
  minY, maxY, rangeX, rangeY: real;
  scaleX, scaleY: real;
  s, s2: string;
  tempS: real;
begin
  // 1. Найдем минимум и максимум функции на отрезке [a, b]
  minY := f(a);
  maxY := f(a);
  
  x := a;
  while x <= b do
  begin
    y := f(x);
    if y < minY then minY := y;
    if y > maxY then maxY := y;
    x := x + 0.1;
  end;
  
  // Добавим немного места сверху и снизу
  minY := minY - 10;
  maxY := maxY + 10;
  
  // 2. Установим размеры области рисования
  width := WindowWidth - 100;
  height := WindowHeight - 100;
  x0 := 50;
  y0 := WindowHeight - 50;
  
  // 3. Рассчитаем масштабы
  rangeX := b - a;
  rangeY := maxY - minY;
  
  if rangeX = 0 then rangeX := 1;
  if rangeY = 0 then rangeY := 1;
  
  scaleX := width / rangeX;
  scaleY := height / rangeY;
  
  // 4. Очистим экран и нарисуем оси
  ClearWindow(clWhite);
  
  // Рисуем оси координат
  SetPenColor(clBlack);
  SetPenWidth(2);
  
  // Ось X
  Line(x0, y0, x0 + width, y0);
  // Ось Y
  Line(x0, y0 - height, x0, y0);
  
  // Стрелки на осях
  Line(x0 + width, y0, x0 + width - 10, y0 - 5);
  Line(x0 + width, y0, x0 + width - 10, y0 + 5);
  Line(x0, y0 - height, x0 - 5, y0 - height + 10);
  Line(x0, y0 - height, x0 + 5, y0 - height + 10);
  
  // Подписи осей
  SetFontColor(clBlack);
  SetFontSize(12);
  TextOut(x0 + width - 15, y0 + 10, 'X');
  TextOut(x0 - 20, y0 - height - 15, 'Y');
  
  // 5. Разметка оси X
  for i := 0 to 10 do
  begin
    var tickX := x0 + Round(i * width / 10);
    Line(tickX, y0 - 5, tickX, y0 + 5);
    
    // Подпись значения
    x := a + (rangeX * i / 10);
    Str(x:0:1, s);
    TextOut(tickX - 10, y0 + 15, s);  // Сдвигаем подписи вправо
  end;
  
  // Разметка оси Y
  for i := 0 to 10 do
  begin
    var tickY := y0 - Round(i * height / 10);
    Line(x0 - 5, tickY, x0 + 5, tickY);
    
    // Подпись значения
    y := minY + (rangeY * i / 10);
    Str(y:0:1, s2);
    SetFontSize(10);
    TextOut(x0 - 40, tickY - 7, s2);  // Сдвигаем подписи значений оси Y
  end;
  
  // 6. Рисуем график функции
  SetPenColor(clBlue);
  SetPenWidth(3);
  
  var prevScreenX := -1;
  var prevScreenY := -1;
  
  for i := 0 to 100 do
  begin
    x := a + (rangeX * i / 100);
    y := f(x);
    
    var screenX := x0 + Round((x - a) * scaleX);
    var screenY := y0 - Round((y - minY) * scaleY);
    
    if (screenX >= x0) and (screenX <= x0 + width) and
       (screenY >= y0 - height) and (screenY <= y0) then
    begin
      if (prevScreenX >= 0) and (prevScreenY >= 0) then
      begin
        Line(prevScreenX, prevScreenY, screenX, screenY);
      end;
      prevScreenX := screenX;
      prevScreenY := screenY;
    end
    else
    begin
      prevScreenX := -1;
      prevScreenY := -1;
    end;
  end;
  
  // 7. Рисуем прямоугольники для метода численного интегрирования
  SetPenColor(clGreen);
  SetBrushColor(RGB(255, 150, 150));
  
  var step := rangeX / n;
  x := a;
  
  for i := 0 to n - 1 do
  begin
    y := f(x);
    
    var x1 := x0 + Round((x - a) * scaleX);
    var x2 := x0 + Round((x + step - a) * scaleX);
    var yScreen := y0 - Round((y - minY) * scaleY);
    
    if (x1 >= x0) and (x1 <= x0 + width) and
       (x2 >= x0) and (x2 <= x0 + width) and
       (yScreen >= y0 - height) and (yScreen <= y0) then
    begin
      Rectangle(x1, y0, x2, yScreen);
    end;
    
    x := x + step;
  end;
  
  // 8. Добавляем подписи
  SetFontColor(clBlack);
  SetBrushColor(clWhite);
  SetFontSize(10);
  TextOut(100, 5, 'График функции: f(x) = 2x³ + 2x² + 5x + 19');
  
  LeftRectangles(a, b, n, tempS);
  
  Str(a:0:2, s);
  Str(b:0:2, s2);
  TextOut(100, 20, 'Пределы: [' + s + ', ' + s2 + ']');
  
  TextOut(100, 40, 'Прямоугольников: ' + IntToStr(n));
  
  Str(tempS:0:4, s);
  TextOut(100, 60, 'Площадь: ' + s);
  
  // Информация о графике
  SetFontColor(clNavy);
  SetFontSize(10);
  TextOut(10, WindowHeight - 15, 'Метод прямоугольников для численного интегрирования');
end;

// Основная программа
begin
  var a, b: real;
  var n: integer;

  // Ввод значений
  write('Введите левый предел a: ');
  readln(a);
  write('Введите правый предел b: ');
  readln(b);
  write('Введите количество прямоугольников n: ');
  readln(n);


  // Открываем окно и рисуем график
  SetWindowSize(800, 600);
  SetWindowTitle('График функции и интегрирование');
  drawGraph(a, b, n);

  // Ожидаем, пока пользователь нажмёт клавишу для закрытия
  readln;
  
  CloseWindow;  // Закрытие окна после нажатия клавиши
end.
