﻿program one;
var filetext: text;
a:string;
i:integer;
begin
  assign (filetext, 'C:\Users\dlebe\Колледж\Оаип\LR\LR-12\файлы\1.txt');
  rewrite (filetext);//открыть фаил для записи
  for i:= 1 to 10 do
  begin
    writeln (filetext, i);//записываются числа
  end;
  
  close (filetext);//закрываем после записи
  reset (filetext);//открываем для чтения
  
  for i:=1 to 10 do
  begin
    readln (filetext, a);
    writeln(a);
  end;
   
   close (filetext);
end.