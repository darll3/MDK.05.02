﻿program five;
var
  inputFile, outputFile: text;
  number, min, max: integer;
  firstLine: boolean;
  N,i: integer;
  
begin
  assign(inputFile, 'C:\Users\dlebe\Колледж\Оаип\LR\LR-12\файлы\input.txt');
  rewrite(inputFile);

  writeln('Введите количество случайных чисел (до 100):');
  readln(N);

  if N > 100 then
    N:= 100;
  randomize;
  for i:= 1 to N do
  begin
    number:= random(100) + 1;
    writeln(inputFile, number);
  end;

  close(inputFile);
  assign(inputFile, 'C:\Users\dlebe\Колледж\Оаип\LR\LR-12\файлы\input.txt');
  reset(inputFile);//отктие для чтения

  assign(outputFile, 'C:\Users\dlebe\Колледж\Оаип\LR\LR-12\файлы\output.txt');  // Путь к выходному файлу
  rewrite(outputFile);

  firstLine := true;//тип первая строка

  // Читаем числа из файла
  while not eof(inputFile) do
  begin
    readln(inputFile, number);  // Считываем число из файла
    
    // считает мин и мак на первром числе
    if firstLine then
    begin
      min:= number;
      max:= number;
      firstLine := false;
    end
    else
    begin
      // Обновление
      if number < min then
        min:= number;
      if number > max then
        max:= number;
    end;
  end;

  // Записываем минимальное и максимальное значения в выходной файл
  writeln(outputFile, 'Минимальное число: ', min);
  writeln(outputFile, 'Максимальное число: ', max);

  close(inputFile);
  close(outputFile);

  writeln('Операция завершена. Минимальное и максимальное числа записаны в output.txt');
end.
