﻿program four;
var
  filetext, tempfile: text;
  line:string;
  K, currentLine:integer;
  inputFileName, tempFileName:string;

begin
  inputFileName:= 'C:\Users\dlebe\Колледж\Оаип\LR\LR-12\файлы\4.txt';  // Исходный файл
  tempFileName:= 'C:\Users\dlebe\Колледж\Оаип\LR\LR-12\файлы\tempfile.txt';  // Временный файл

  writeln('Введите номер строки K:');// перед которой должна стоять пустая сторка 
  readln(K);

  // Открываем исходный файл для чтения
  assign(filetext, inputFileName);
  reset(filetext);

  // Открываем временный файл для записи
  assign(tempfile, tempFileName);
  rewrite(tempfile);

  // Считываем строки из исходного файла и записываем в временный файл
  currentLine := 1;
  while not eof(filetext) do
  begin
    // Считываем строку из исходного файла
    readln(filetext, line);

    // Если текущая строка с номером K, вставляем пустую строку
    if currentLine = K then
      writeln(tempfile);  // Пустая строка перед строкой K

    // Записываем строку из исходного файла в временный файл
    writeln(tempfile, line);

    // Переходим к следующей строке
    inc(currentLine);
  end;

  close(filetext);
  close(tempfile);

  // Заменяем исходный файл временным
  erase(filetext);  // Удаляем старый файл
  rename(tempfile, inputFileName);  // Переименовываем временный файл в исходный

  writeln('Операция завершена. Пустая строка вставлена (если строка с номером K существует).');
end.
