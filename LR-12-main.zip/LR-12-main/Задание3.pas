﻿program tree;
var filetext: text;
s:string;
begin
  readln(s);
  assign (filetext, 'C:\Users\dlebe\Колледж\Оаип\LR\LR-12\файлы\3.txt');
  append (filetext);//в конец
  writeln(filetext, s);
  close (filetext);
end.