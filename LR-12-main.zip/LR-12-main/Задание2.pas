﻿program two;
var filetext:text;
N,K,i:integer;
stars:string;
begin
  readln(N);//кол-во строк
  readln(K);//кол-во * в сроке
  assign (filetext, 'C:\Users\dlebe\Колледж\Оаип\LR\LR-12\файлы\2.txt');
  rewrite(filetext);//открыть фаил для записи
  
  stars:= StringOfChar ('*',K);//строка из*
  for i:= 1 to N do
  begin
    writeln(filetext, stars);//строка с K звездочками в файл
  end;
  close(filetext);
end.
