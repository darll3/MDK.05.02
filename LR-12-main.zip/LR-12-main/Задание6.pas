﻿program six;
var
  inputFile, outputFile: text;
  line: string;
  inputFileName, outputFileName: string;
begin
  
  inputFileName:= 'C:\Users\dlebe\Колледж\Оаип\LR\LR-12\файлы\input1.txt';
  outputFileName:= 'C:\Users\dlebe\Колледж\Оаип\LR\LR-12\файлы\output1.txt';

  assign(inputFile, inputFileName);
  reset(inputFile);//чтение

  assign(outputFile, outputFileName);
  rewrite(outputFile);//запись

  while not eof(inputFile) do
  begin
    readln(inputFile, line);//считываем строки

    if Trim(line) <> '' then
      writeln(outputFile, line);
  end;

  close(inputFile);
  close(outputFile);

  writeln('Пустые строки удалены.');
end.
