﻿program seven;

var
  f: file of char;
  c: char;
  i: Integer;//позиция символов
  fileName: string;

begin
  fileName := 'C:\Users\dlebe\Колледж\Оаип\LR\LR-13\фаил\file.txt';

  AssignFile(f, fileName);
  Reset(f);

  i := 0;
  //идем по всем символам в фаллей
  while not EOF(f) do
  begin
    Seek(f, i);
    Read(f, c);
    
    if (i mod 2 = 1) then//если поз четная 
      c := '!';

    Seek(f, i);
    Write(f, c);  // Записываем измененный символ обратно в файл

    Inc(i);  // Переходим к следующей позиции
  end;

  CloseFile(f);

  WriteLn('Все символы на четных позициях заменены на восклицательные знаки.');
end.
