﻿program six;

var
  inputFile, outputFile: TextFile;
  numbers: array of Real;
  num, minNum, maxNum: Real;
  minIndex, maxIndex, count, i: Integer;
  fileName: string;

begin
  fileName := 'C:\Users\dlebe\Колледж\Оаип\LR\LR-13\фаил\input6.txt';
  
  AssignFile(inputFile, fileName);
  Reset(inputFile);
  
  count := 0;

  while not EOF(inputFile) do
  begin
    ReadLn(inputFile, num);
    Inc(count);
    SetLength(numbers, count);
    numbers[count - 1] := num;
  end;

  CloseFile(inputFile);

  minNum := numbers[0];
  maxNum := numbers[0];
  minIndex := 0;
  maxIndex := 0;

  //Поиск минимального и максимального чисел
  for i := 1 to count - 1 do
  begin
    if numbers[i] < minNum then
    begin
      minNum := numbers[i];
      minIndex := i;
    end;
    if numbers[i] > maxNum then
    begin
      maxNum := numbers[i];
      maxIndex := i;
    end;
  end;

  AssignFile(outputFile, 'C:\Users\dlebe\Колледж\Оаип\LR\LR-13\фаил\output6.txt');
  Rewrite(outputFile);

  for i := 0 to count - 1 do
  begin
    if i = minIndex then
      WriteLn(outputFile, maxNum) //максимальное число на место минимального 
    else if i = maxIndex then
      WriteLn(outputFile, minNum) //минимальное число на место максимального
    else
      WriteLn(outputFile, numbers[i]);//остальные числа остаются на своих местах
  end;

  CloseFile(outputFile);

  WriteLn('Минимальное и максимальное значения поменяны местами в файле.');
end.
