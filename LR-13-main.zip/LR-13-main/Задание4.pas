﻿program SumEvenNumbers;

var
  inputFile: TextFile;
  num: Real;
  lineNumber: Integer; //Номер строки для определения четности/нечетности
  sum: Real;
  fileName: string;

begin
  fileName := 'C:\Users\dlebe\Колледж\Оаип\LR\LR-13\фаил\input4.txt';

  AssignFile(inputFile, fileName);
  Reset(inputFile);

  sum := 0;
  lineNumber := 1;

  while not EOF(inputFile) do
  begin
    ReadLn(inputFile, num);

    if (lineNumber mod 2 = 0) then
      sum:= sum + num;

    Inc(lineNumber);
  end;

  CloseFile(inputFile);

  WriteLn('Сумма чисел с четными номерами: ', sum:0:2);
end.
