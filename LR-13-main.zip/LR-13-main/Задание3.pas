﻿program SplitNumbers;

var
  inputFile, oddFile, evenFile: TextFile;
  num: Real;//Для хранения вещественного числа
  lineNumber: Integer; //Номер строки для определения четности/нечетности
  fileName: string;

begin
  fileName := 'C:\Users\dlebe\Колледж\Оаип\LR\LR-13\фаил\input3.txt';

  AssignFile(inputFile, fileName);
  Reset(inputFile);

  AssignFile(oddFile, 'C:\Users\dlebe\Колледж\Оаип\LR\LR-13\фаил\odd_numbers.txt');
  Rewrite(oddFile);
  AssignFile(evenFile, 'C:\Users\dlebe\Колледж\Оаип\LR\LR-13\фаил\even_numbers.txt');
  Rewrite(evenFile);

  lineNumber := 1;//номер строки начинается с 1

  // Чтение чисел и разделение их на два файла 
  while not EOF(inputFile) do
  begin
    ReadLn(inputFile, num);

    //Если номер строки нечетный, записываем в файл для нечетных чисел 
    if (lineNumber mod 2 = 1) then
      WriteLn(oddFile, num)
    else 
      WriteLn(evenFile, num);

    Inc(lineNumber); //Увеличиваем номер строки на 1 
  end;

  CloseFile(inputFile);
  CloseFile(oddFile);
  CloseFile(evenFile);

  WriteLn('Числа разделены на два файла: "odd_numbers.txt" и "even_numbers.txt".');
end.
