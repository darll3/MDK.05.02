﻿program five;
var
  inputFile: TextFile;
  numbers: array of Real;
  num: Real;
  i, count: Integer;
  lastLocalMax: Real;
  fileName: string;

begin
  fileName := 'C:\Users\dlebe\Колледж\Оаип\LR\LR-13\фаил\input5.txt';

  AssignFile(inputFile, fileName);
  Reset(inputFile);

  count := 0;

  //Чтение всех чисел из файла в массив
  while not EOF(inputFile) do
  begin
    ReadLn(inputFile, num);
    Inc(count);
    SetLength(numbers, count);
    numbers[count - 1] := num;
  end;

  CloseFile(inputFile);

  lastLocalMax := -MaxInt;

  for i := 1 to count - 2 do  //Проверяем с 2 числа по предпоследнее
  begin
   //проверяем локал макс
    if (numbers[i] > numbers[i - 1]) and (numbers[i] > numbers[i + 1]) then
      lastLocalMax := numbers[i];
  end;


  if lastLocalMax = -MaxInt then
    WriteLn('Локальный максимум не найден.')
  else
    WriteLn('Последний локальный максимум: ', lastLocalMax:0:2);

end.
