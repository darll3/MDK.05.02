﻿program MaxLengthLinesReversed;

var
  inputFile, outputFile: TextFile;
  line: string;
  maxLength: Integer;
  lines: array of string;//хранение макс длины
  i, count: Integer;
  fileName: string;

begin
  fileName := 'C:\Users\dlebe\Колледж\Оаип\LR\LR-13\фаил\input2.txt';
  
  AssignFile(inputFile, fileName);
  Reset(inputFile);

  maxLength:= 0;
  count:= 0;

//ищем макс длину
  while not EOF(inputFile) do
  begin
    ReadLn(inputFile, line);
    if Length(line) > maxLength then
    begin
      maxLength:= Length(line);
      count:= 1; 
      SetLength(lines, count);
      lines[0]:= line;//первая строка макс длины
    end
  end;

  CloseFile(inputFile);

  AssignFile(outputFile, 'C:\Users\dlebe\Колледж\Оаип\LR\LR-13\фаил\output2.txt');
  Rewrite(outputFile);

  for i := count - 1 downto 0 do
    WriteLn(outputFile, lines[i]);//записываем в обратном порядке

  CloseFile(outputFile);

  WriteLn('Строки максимальной длины записаны в обратном порядке в файл "output2.txt".');
end.
