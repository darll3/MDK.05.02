﻿program one;
uses GraphABC;
var x1,x2,y1,y2,x3,y3,x4,y4,t1,r1,t2,r2,t3,r3:integer;
begin
  x1:=100; y1:=100;
  x2:=200; y2:=100;
  x3:=200; y3:=200;
  x4:=100; y4:=200;
  SetPenColor (clTeal);
  MoveTo (x1,y1);
  LineTo (x2,y2);
  LineTo (x3,y3);
  LineTo (x4,y4);
  LineTo (x1, y1);
  t1:=400;r1:=100;
  t2:=300;r2:=200;
  t3:=500;r3:=200;
  SetPenColor (clBlue);
  MoveTo (t1,r1);
  LineTo (t2,r2);
  LineTo (t3,r3);
  LineTo (t1,r1);
end.