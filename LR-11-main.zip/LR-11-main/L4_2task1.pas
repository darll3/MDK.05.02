﻿program two;
uses GraphABC;
begin
  setpenwidth(2);
  setpencolor (clblack);
  
  Circle(100,100,50);
  FloodFill(100,100,clred);
  
  MoveTo(500, 100);
  LineTo(150,100);
  LineTo (325,200);
  LineTo (500,100);
  floodfill(330,150, clGreen);
  
  Circle (550,100,50);
  FloodFill(550,100,clYellow);
  
  moveto (150,100);
  lineto(325,5);
  lineto(500,100);
  lineto(150,100);
  floodfill (330,20,clBlue);
end.