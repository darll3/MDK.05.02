﻿program senven;
uses GraphABC;
var
  x,y,size:integer;
  i,j:integer; // столбики и строки

begin
  x:=50;
  y:=50;
  size:=40;

  SetWindowSize(400, 400);
//клекти
  for i := 0 to 7 do
    for j := 0 to 7 do
    begin
      Brush.Color := if (i + j) mod 2 = 0 then clWhite else clBlack;
      FillRectangle(x + i*size,y + j*size,x + (i+1)*size,y + (j+1)*size);
    end;

  Pen.Color:=clBlack;
  Pen.Width:=3;
  Brush.Style:=bsClear;
  Rectangle(x,y,x + 8*size,y + 8*size);
end.
