﻿program six;
uses GraphABC;
var x,y,r,i:integer;
begin
  setwindowsize(600,400);
  x:=50;
  y:=50;
  r:=10;
  for i:= 1 to 8 do
  begin
    setbrushcolor(rgb(random(256),random(256),random(256)));
    setpencolor(clblack);
    circle (x,y,r);
    x+=40;
    y+=20;
    r+=10;
  end;
end.
