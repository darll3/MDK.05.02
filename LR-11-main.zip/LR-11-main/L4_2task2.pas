﻿program tree;
uses GraphABC;
begin
  setpenwidth (2);
  setpencolor(clblack);
  
  moveto(300,500);
  lineto(400,500);
  lineto(424,400);
  lineto(225,200);
  lineto(215,210);
  lineto(300,500);
  floodfill(350,450,clblue);
  
  moveto(400,500);
  lineto(600,500);
  lineto(505,100);
  lineto(495,100);
  lineto(400,500);
  floodfill(450,300,clred);
  
  moveto(700,500);
  lineto(600,500);
  lineto(576,400);
  lineto(775,200);
  lineto(785,210);
  lineto(700,500);
  floodfill(650,400,clgreen);
  
  circle (205,180,40);
  floodfill(205,180,clblue);
  
  circle (795,180,40);
  floodfill (795,180,clgreen);
  
  circle (500,90,40);
  floodfill(490,100,clred);
  

end.