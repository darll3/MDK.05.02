﻿program four;
uses GraphABC;
var x,r,y:integer;
begin
  setwindowsize(400,200);
  x:=50;
  r:=10;
  y:=100;
  while x<=290 do
  begin
    setbrushcolor(rgb(random(256),random(256),random(256)));
    setpencolor(clblack);
    circle(x,y,r);
    x+=30;
  end;
end.