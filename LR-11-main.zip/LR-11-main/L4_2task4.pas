﻿program five;
uses GraphABC;
var r,cy,cx:integer;
begin
  setwindowsize(600,600);
  cx:=windowwidth div 2;
  cy:=windowheight div 2;
  for r:= 10 to 200 step 10 do
  begin
    setpencolor(clblack);
    SetBrushColor(clTransparent);
    circle(cx,cy,r);
  end;
end.