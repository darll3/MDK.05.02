﻿   function sumTo (n: integer): integer;//n: integer - параметризация
   begin
        if (n<=1) then //n>1 - база рекурсии
          n:=1
        else
          n:=n+(sumTo(n-1));// n:=n+(sumTo(n-1))- декомпозиция
   sumTo:=n;
end;
begin
var x:= ReadInteger('Число?');
print(sumTo(x));
end.