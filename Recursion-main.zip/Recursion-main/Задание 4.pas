﻿procedure LoopFor(i, n: integer);// парампетризация
{Первый параметр – счетчик шагов, второй параметр – общее количество шагов}
begin
  print ('привет',i);
  if i< n then // база рекурсии
    LoopFor (i+1,n);//декомпозиция            
end;
begin
  LoopFor(1,10);                    
end.