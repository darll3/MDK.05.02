﻿
function stepen (a,b: integer):integer;//a,b: integer - параметризации
begin
 if b<0 then stepen:=1//база рекурсии
 else stepen := a * stepen(a, b - 1);//декомпозиция
end;
begin
  var x:= ReadInteger('число?');
  var y:= ReadInteger('степень?');
  print(stepen(x,y));
end.