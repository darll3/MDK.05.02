﻿procedure row(n:integer);//n:integer - параметризация
begin
     if n >=1 then begin//n<1 - база рекурсии
        print(n, ' ');
        row(n-2)//row(n-2) - декомпозиция
     end;
end;
begin
    row(25);
end.