﻿program dkr3;
uses CRT;
var a,b,S,S1:real;
n,n1,choice:integer;

  function f(x:real):real;
  begin
    f:=2*x*x*x+2*x*x+5*x+19;
  end;

  procedure square(a,b:real; n:integer; var S:real);
  var h,x:real;
  begin
    h:=(b-a)/n;
    x:=a;
    S:=0;
    while x<b do
      begin
      S+=f(x);
      x+=h;
      end;
  S*=h;
  end;
  
begin
  repeat
    clrscr;
    writeln('МЕНЮ');
    writeln('1. Ввод данных и вычисление площади');
    writeln('2. Вычисление площади с другим числом прямоугольников');
    writeln('3. Абсолютная погрешность');
    writeln('4. Относительная погрешность');
    writeln('5. Показать результаты последнего расчета');
    writeln('6. Выход');
    write('Ваш выбор: ');
    readln(choice);
    
    case choice of
      1:begin
        clrscr;
        writeln('Вычисление площади');
        write('Введите левый предел a: ');
        readln(a);
        write('Введите правый предел b: ');
        readln(b);
        write('Введите количество прямоугольников n: ');
        readln(n);
        square(a,b,n,S);
        writeln('Площадь = ', S:0:6);
        readln;
        end;
      2:begin
        clrscr;
        writeln('Оценка погрешности');
        if (S=0) or (n=0) then
        begin
          writeln ('Сначала выберите пункт 1!');
          readln;
        end
        else 
          begin
          write ('Введите другое количество прямоугольников n1: ');
          readln(n1);
          square(a,b,n1,S1);
          writeln ('Площадь со старым количеством прямоугольников n = ',S:0:6);
          writeln ('Площадь с новым количеством прямоугольников n1 = ',S1:0:6);
          writeln ('Погрешность = ', abs(S1-S):0:6);
          readln;
          end;
          end;
       3:begin
          clrscr;
           if (S=0) or (n=0) or (S1=0) or (n1=0) then
             writeln('Сначала выполните пункты 1 и 2!')
           else
           begin
             writeln('Абсолютная погрешность:');
             writeln('Старая площадь (S) = ', S:0:6);
             writeln('Новая площадь (S1) = ', S1:0:6);
             writeln('Абсолютная погрешность = ', abs(S1-S):0:6);
           end;
           readln;
         end;

      4: begin
         clrscr;
           if (S=0) or (n=0) or (S1=0) or (n1=0) then
             writeln('Сначала выполните пункты 1 и 2!')
           else
           begin
             writeln('Относительная погрешность:');
             writeln('Старая площадь (S) = ', S:0:6);
             writeln('Новая площадь (S1) = ', S1:0:6);
             writeln('Относительная погрешность = ', abs(S1-S)/abs(S):0:6);
           end;
           readln;
         end;

      5: begin
         clrscr;
           if (S=0) or (n=0) or (S1=0) or (n1=0) then
             writeln('Сначала выполните пункты 1 и 2!')
           else
           begin
             writeln('Все результаты:');
             writeln('Старая площадь (S) = ', S:0:6); 
             writeln('Новая площадь (S1) = ', S1:0:6);
             writeln('Абсолютная погрешность = ', abs(S1-S):0:6);
             writeln('Относительная погрешность = ', abs(S1-S)/abs(S):0:6);
           end;
           readln;
         end;
      6: begin
           clrscr;
           writeln('Выход из программы...');
           readln;
         end;
     end;
  until choice = 6;
end.